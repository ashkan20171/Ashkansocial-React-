import React from 'react';
import { Grid, Card, CardContent, Typography } from '@mui/material';

const Post = ({ content }) => (
  <Card sx={{ marginBottom: '16px' }}>
    <CardContent>
      <Typography variant="body1">{content}</Typography>
    </CardContent>
  </Card>
);

const Feed = () => {
  const posts = ["Post 1", "Post 2", "Post 3", "Post 4"]; // نمونه پست‌ها

  return (
    <Grid container spacing={2}>
      {posts.map((post, index) => (
        <Grid item xs={12} sm={6} md={4} key={index}>
          <Post content={post} />
        </Grid>
      ))}
    </Grid>
  );
};

export default Feed;
