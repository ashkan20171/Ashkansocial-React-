import React from 'react';
import { Badge, Button } from '@mui/material';

const Notifications = () => {
  // فرض بر این است که تعداد نوتیفیکیشن‌ها 5 باشد
  const notificationCount = 5;

  return (
    <Badge badgeContent={notificationCount} color="secondary">
      <Button color="inherit">Notifications</Button>
    </Badge>
  );
};

export default Notifications;
